K = Circuit('ex30211m.txt');

clc
addpath(genpath('../!!!ELABorate-master'))

disp('The netlist')
disp(' ')
disp(K.list)
disp('_____________________________________________________')
ELAB.analyze(K);
ELAB.evaluate(K);
snv=K.symbolic_node_voltages;
sev=K.symbolic_element_voltages;
sec=K.symbolic_element_currents;
ssc=K.symbolic_source_currents;
nnv=K.numerical_node_voltages;
nev=K.numerical_element_voltages;
nec=K.numerical_element_currents;
nsc=K.numerical_source_currents;
disp('_____________________________________________________')
disp('The node voltages')
disp(' ')
for i=1:length(nnv)
	fprintf('%s%s%s\n',string(lhs(nnv(i))),'=',num2str(eval(rhs(nnv(i)))))
end
disp('_____________________________________________________')
disp('The branch currents')
disp(' ')
for i=1:length(nec)
	fprintf('%s%s%s\n',string(lhs(nec(i))),'=',num2str(eval(rhs(nec(i)))))
end
disp('_____________________________________________________')
disp('The branch voltages')
disp(' ')
for i=1:length(nev)
	fprintf('%s%s%s\n',string(lhs(nev(i))),'=',num2str(eval(rhs(nev(i)))))
end
disp('_____________________________________________________')