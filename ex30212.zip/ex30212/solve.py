from lcapy import *
import os

state.current_sign_convention = 'passive' # active passive hybrid
#os.environ['PATH']=os.pathsep.join(['d:/TexLive/2019/bin/win32',os.environ['PATH']])
#print(os.environ['PATH'])
K = Circuit('ex30202.txt')


print(" "); print("========== Netlist  ============"); print(" ")
print(K.netlist())

print(" "); print("======== Node Voltages  ========"); print(" ")
for k in K.nodes:
    if '_' not in k:
        print('v'+k+'='+K[k].V.latex())

print(" "); print("======== Branch Currents ======="); print(" ")
Z=K.branch_currents()
for z in Z:
    txt=str(z.dc)
    print(txt)

print(" "); print("======== Branch Voltages ========"); print(" ")
Z=K.branch_voltages()
for z in Z:
    txt=str(z.dc)
    txt=txt.replace("})","")
    print(txt)
#######################################################################
print(" "); print("======== Node Equations ========"); print(" ")
na=NodalAnalysis(K)
print(na.matrix_equations(form='A y = b'))

print(" "); print("======== Loop Equations ========"); print(" ")
la=LoopAnalysis(K)
print(la.matrix_equations(form='A y = b'))

print(" "); print("================================"); print(" ")
show_version()