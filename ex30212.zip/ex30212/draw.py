from lcapy import *

state.current_sign_convention = 'passive'
K = Circuit('ex30212.txt')
K.draw("ex30212.png",dpi=2400)
K.draw("ex30212sch.pdf")