from lcapy import *

name = 'ex30213'
state.current_sign_convention = 'passive'
K = Circuit(name + '.txt')
K.draw(name + ".png",dpi=2400)
K.draw(name + "sch.pdf")